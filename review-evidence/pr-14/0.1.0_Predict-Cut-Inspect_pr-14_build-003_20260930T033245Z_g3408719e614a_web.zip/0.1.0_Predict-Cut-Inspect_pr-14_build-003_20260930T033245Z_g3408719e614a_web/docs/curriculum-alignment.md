# Curriculum Alignment

MeasureTwice practices a narrow part of **DM 1.3 Measuring Matters**: interpreting fractional-inch positions and relating a specified measurement to a part. Keep the broader activity, its physical work, and its metric work visible as context without claiming this game covers them all.

This file owns the source record. [Curriculum Content](curriculum-content.md) documents each proposed Learn review and Challenge check, its goal/evidence relationship, and links to the class repository and planning document. [Free Play Learn and Challenge](game-modes.md) defines the shared mode structure and the planned in-game Curriculum access. Every future lesson and check must extend that index before release.

## Sources Reviewed

**September 30 Verification:** The cited primary pages for all seven selected targets and audit pp. 1-3 have now been read and visually checked. See [Selected Primary-Source Verification](PRIMARY_SOURCE_VERIFICATION.md) for exact hashes, checked pages, resolved Goals pagination and remaining edition limits. The source-status notes below preserve the earlier planning pass.

Rechecked September 28, 2026 (America/New_York) after MeasureTwice PR #10 merged. DM main is now `a300f296b0bd66775f067acff23d5e7988109c51` after the Dialed In audit merge. Its 1.3 lesson files, goal inventory, identifier rules, and quick-build index have unchanged Git blobs relative to the pinned `3e5d892a593df9ab385593eb342314c80c65caf4` references below. PR #21 remains at `1713a3bd537035f2ce09dfc7fe05ce6bf6b70cc3`; it and process PR #34 remain open drafts. The accepted gameplay foundation is [Game Design](game-design.md); the current content record contains five Learn scripts and six seed Challenge items. This check confirms source status and file continuity, not a new primary-source audit.

| Source | Checked Revision And Status | Use |
| --- | --- | --- |
| [DM 1.3 Item Index](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/3e5d892a593df9ab385593eb342314c80c65caf4/units/01-introduction-to-design/1.3-measuring-matters/README.md) | Pinned reviewed main `3e5d892a593df9ab385593eb342314c80c65caf4`; unchanged at current checked main above. | Activity identity, current material paths, and source navigation. |
| [1.3 Curricular Goals Audit](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/1713a3bd537035f2ce09dfc7fe05ce6bf6b70cc3/units/01-introduction-to-design/1.3-measuring-matters/teacher-guides/measuring-matters-curricular-goals.docx) and [Reading PDF](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/1713a3bd537035f2ce09dfc7fe05ce6bf6b70cc3/units/01-introduction-to-design/1.3-measuring-matters/teacher-guides/measuring-matters-curricular-goals.pdf) | [PR #21](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/pull/21), open and draft when checked; head `1713a3bd537035f2ce09dfc7fe05ce6bf6b70cc3`. The guide index records teacher acceptance of the audit. | Full DOCX text and guide index read for target descriptions, cited source pages, and instructional limits. |
| [Existing Goal Inventory](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/3e5d892a593df9ab385593eb342314c80c65caf4/shared-resources/assessment-bank/learning-compass/reference/official-goal-inventory.csv) and [Identifier Rules](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/3e5d892a593df9ab385593eb342314c80c65caf4/curriculum/README.md) | Pinned reviewed main; unchanged at current checked main above. | Preserve existing Learning Compass identifiers and distinguish source goals from local targets. |
| [Tinkercad Quick-Build Template Index](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/3e5d892a593df9ab385593eb342314c80c65caf4/templates/slides/tinkercad-quick-build/README.md) | Pinned reviewed main; index previously read and unchanged at current checked main above. | Familiar composite-object challenge context; not a 1.3 measurement requirement. |
| [Curricular Goals First Proposal](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/pull/34) | Open draft when checked. | Tracks the proposed curriculum-only audit process and future `curricular-goals/` home. Treat proposed paths as future paths. |

The detailed mapping below relies on the reviewed audit's source analysis (selected targets on audit pp. 2–3). The original 67-page PLTW activity PDF was **not independently re-audited in this planning pass**. References such as “A pp. 11–25” are the audit's locators into [the archived activity](https://github.com/AbbyUsesAIThatCodes/DesignAndModeling26-27/blob/3e5d892a593df9ab385593eb342314c80c65caf4/units/01-introduction-to-design/1.3-measuring-matters/reference/13-measuringmatters.pdf), not claims of a fresh primary-source inspection. The source edition is unresolved in the DM record.

## Selected Targets

The `G` labels are local analytical labels from the audit. Always qualify them with `DM 1.3`; they are not official PLTW or Ohio standard codes.

| Audit Target | Source Locator Reported By The Audit | MeasureTwice Use | Evidence And Limits |
| --- | --- | --- | --- |
| DM 1.3 G07 — Value And Unit | A p. 5; pp. 44, 49, 66 | Every target and result retains an inch unit. | Unit labeling supports the task; the game does not assess unit selection if inches are supplied automatically. |
| DM 1.3 G10 — Equal Ruler Intervals | A p. 11; p. 66 | Use subdivisions to find a requested position. | An unassisted selection gives limited interpretation evidence; a short explanation can probe interval reasoning. |
| DM 1.3 G11 — Fractional Inches | A step 3, pp. 11–25 | Select positions through sixteenths of an inch. | Core individual response: target and selected location. |
| DM 1.3 G12 — Equivalent Fractions | A pp. 15, 17–21, 23, 25 | Vary equivalent fractional prompts across builds; normalize them to the same physical length. | Normalization alone does not assess the student. Use unassisted alternate representations and a short explanation or comparison to collect stronger evidence. |
| DM 1.3 G13 — Mixed Numbers | A step 6, p. 39 | Locate whole inches plus a fractional remainder. | Preserve errors that omit the whole-inch part instead of flattening all wrong clicks into one category. |
| DM 1.3 G16 — Starting Graduation | A step 5, pp. 37–38 | Keep zero visible or recoverable independently of the ruler edge. | Fixed automatic alignment is scaffolding; it does not demonstrate that a student can align a physical ruler. |
| DM 1.3 G08 — Why Accuracy Matters | A pp. 5, 42, 47, 66 | Every valid selected length is cut and inspected against the target; accepted parts enter the build and incorrect parts show excess or missing material. | Post-cut comparison supplies motivating context. MT-L05 teaches fit consequences; MT-C05 asks for an explanation on a fresh neutral example before showing the diagnosis. Watching feedback alone is not understanding evidence. |

## Existing Course Identifiers

| Existing Identifier | Relationship To This Plan |
| --- | --- |
| `DM-O-1.3-2` / `DM-G11` | Existing umbrella goal and assessment target for accurate ruler measurement. Primary connection, with digital interpretation as partial practice. |
| `DM-O-1.3-1` / `DM-G10` | Covers both measurement systems. Inch-only play is partial exposure, not full coverage. |
| `DM-O-1.3-3` / `DM-G12` | Reading sketch dimensions. Possible later connection only if students actually interpret dimensioned features and endpoints. A number prompt alone is insufficient. |
| `DM-O-1.3-4` / `DM-G13` | Physical paper-skimmer construction. Automatic wooden-model assembly does not satisfy it. |

These inventory IDs are locally assigned course identifiers, even where a CSV column is named `official_goal_id`. They are separate from the audit's `DM 1.3 G11`, `G12`, and `G13`; do not equate them because their numbers look alike.

The older inventory locates the Goals panel on PDF page 2, while the detailed audit locates it on PDF page 3 counting the cover. September 30 verification confirms PDF page 3 for this archive, counting all front matter. Preserve the IDs and use that verified convention. Do not silently rewrite the DM inventory from this game repository.

## Local Design Extensions

- **Empty-space selection:** locating a finer interval on a deliberately sparse ruler is a proposed transfer task, not a separately stated source requirement.
- **Decimal-inch prompts:** useful representation practice; the audit's core decimal-ruler target G14 concerns centimeters. Do not call decimal inches direct G14 coverage.
- **Wood cutting, duplication, and composite models:** the teacher's motivational game design, informed by familiar Dash work. These do not become official 1.3 goals.
- **Keyboard controls and animation options:** access features that let students reach the same mathematical task.

Metric measurement, physical ruler placement, triangle drawing, sketch interpretation, paper-skimmer cutting/folding, and launch testing remain outside the first playable scope. The game does not establish mastery of all four activity goals or current Ohio standards alignment.

## Keep The Connection Current

For each design or implementation issue, identify the selected goal, what the student actually does, what observable response supplies evidence, and which assistance is present. Recheck current DM main and the status of PR #21 before instructional changes. If the audit moves after the curriculum process work, update this source table and links while retaining the pinned historical reference.

Keep curriculum-only audits in DM and mechanics here. The selected primary pages are now verified; before classroom release, publish teacher coverage for the actual game version, including a physical-ruler transfer task. Do not copy the private curricular archive into this public repository or require students to access it.
