@echo off
cd /d "%~dp00.1.0_Predict-Cut-Inspect_pr-20_build-001_20260930T222545Z_g06cbb0da92c3_web"
set "MT_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "MT_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
start "" http://127.0.0.1:18453
"%MT_NODE%" serve.mjs . 18453
pause
