@echo off
cd /d "%~dp00.1.0_Predict-Cut-Inspect_pr-23_build-001_20260930T225840Z_g129d93fa115b_web"
set "MT_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "MT_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
start "" http://127.0.0.1:18453
"%MT_NODE%" serve.mjs . 18453
pause
