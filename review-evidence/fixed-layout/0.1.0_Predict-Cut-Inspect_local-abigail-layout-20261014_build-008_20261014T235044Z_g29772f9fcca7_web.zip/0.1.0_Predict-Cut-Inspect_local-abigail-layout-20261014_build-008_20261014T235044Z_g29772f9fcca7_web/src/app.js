import {instruments,instrument,worldLength,startInstrument,pickStep} from './instruments.js';
import {workshopLayout,comparisonPosition} from './layout.js';
import {gridStep,onGrid,snapToGrid,pickVisible,ensureVisibleTarget,intervalName} from './grid.js';
import {compactBuild} from './build-display.js';
import {preferredRadius,recoverRadius} from './view-limits.js';
import {createConstruction,displayProject} from './construction.js';
import {checks} from './content.js';
import {createWorkshop} from './workshop.js';
import {fraction,pick,newSession,commit,acknowledge,comparisonPlacement,exposeActivity,restartSession} from './model.js';
const $=id=>document.getElementById(id);
const house=await fetch('data/house.json').then(r=>r.json());
let construction=createConstruction(house,checks);
const manifest=await fetch('build-manifest.json').then(r=>r.ok?r.json():null).catch(()=>null);
if(manifest){$('build-id').textContent=compactBuild(manifest);$('build-id').dataset.fullId=manifest.id;console.info(manifest.id)}
let w;try{w=createWorkshop($('stage'))}catch(e){$('load-error').hidden=false;$('load-error').textContent=e.message;throw e}
const {THREE,scene,camera,look,homePos,homeLook,render,box,plank,line,mat,wood,woodLight,woodDark,ghost,bladeGroup,guard,STOCK,SAW_X,BOARD_Y,BOARD_Z,receivingTray}=w;
const sessions={free:newSession('free'),learn:newSession('learn'),challenge:newSession('challenge')};
let s=sessions.free,animation=null,token=0,shiftToken=0,inspection=null,piece=null,offcut=null,highlighted=null;
let preferredOrbitDistance=null,orbitTicket=0,orbitRecovering=false,focusTicket=0,focusMoving=false;
function cancelOrbitRecovery(){orbitTicket++;orbitRecovering=false;focusTicket++;focusMoving=false}
function resetOrbitPreference(){cancelOrbitRecovery();preferredOrbitDistance=preferredRadius(camera.position.distanceTo(look),1,w.orbitLimits)}
const transient=[],placed=[],ghosts=[];
const origin=new THREE.Vector3(84,68.48,22);
let layout=workshopLayout(),stock=plank(STOCK);scene.add(stock);stock.userData.label='Stock: choose a length, then press Cut.';
const comparisonRack=new THREE.Group();comparisonRack.name='Side Build Table';scene.add(comparisonRack);w.addCameraObstacle(comparisonRack);
function configureWorkspace(){
 layout=w.configureSpan(worldLength(instrument(s).max,s));
 stock.children[0].geometry.dispose();stock.children[0].geometry=new THREE.BoxGeometry(layout.stockLength,.22,.63);
 if(!comparisonRack.children.length){
  const center=layout.tableLeft+layout.tableWidth/2;
  for(const [x,z,width,depth,name] of [[center,layout.tableZ,layout.tableWidth,layout.tableDepth,'Comparison Area'],[layout.modelOrigin[0],layout.modelOrigin[2],layout.modelWidth,layout.modelDepth,'Assembly Area']]){
   box(width,.15,depth,woodLight,x,layout.tableTop-.075,z,comparisonRack).name=name;
   for(const dz of [-depth/2,depth/2])box(width,.1,.3,woodDark,x,layout.tableTop+.05,z+dz,comparisonRack);
   for(const dx of [-width/2,width/2])box(.3,.1,depth,woodDark,x+dx,layout.tableTop+.05,z,comparisonRack);
  }
  w.surfaceLabel('Example Cuts',20,center,layout.tableTop+.01,-34.5,comparisonRack,'#46584a');
  w.surfaceLabel('Assembly',16,layout.modelOrigin[0],layout.tableTop+.01,14,comparisonRack,'#46584a');
 }
 // Seat the actual oriented profiles on the surface without changing any part.
 // The plane's rolled landing gear extends 0.0016 world units below its origin.
 for(const p of construction.projects)p.origin=[layout.modelOrigin[0],layout.modelOrigin[1]+(p.id==='house'?.33:p.id==='plane'?.0016:0),layout.modelOrigin[2]];
 $('instrument').value=instrument(s).id;
 $('free-target').innerHTML='<option value="">No Target</option>'+[...new Set(instrument(s).unit==='in'?[16,20,32,instrument(s).max/2,instrument(s).max]:[1,10,instrument(s).max/2,instrument(s).max-1,instrument(s).max])].filter(n=>n<=instrument(s).max).map(n=>`<option value="${n}">${measure(n)}</option>`).join('');
 $('subdivision').innerHTML=instrument(s).unit==='in'?'<option value="2">Halves</option><option value="4">Quarters</option><option value="8">Eighths</option><option value="16">Sixteenths</option>':'<option value="10">Millimetres</option><option value="1">Centimetres</option>';
}
const measure=(n,ref=s)=>instrument(ref).unit==='in'?fraction(n)+' in':n+' mm'+(n%10===0?' ('+(n/10)+' cm)':'');
const length=n=>worldLength(n,s);
const marker=new THREE.Group();line([[0,.13,-.35],[0,.13,.35]],0x304e60,marker);const pointerHandle=new THREE.Mesh(new THREE.SphereGeometry(.13,12,8),mat(0x305e7a));pointerHandle.position.set(0,.15,.55);marker.add(pointerHandle);scene.add(marker);
let hooks={},cameraChoice='cut',exposureObserver=()=>{};
const emit=text=>{$('live').textContent=text};
const world=p=>new THREE.Vector3(...p.map(n=>n/8)).add(origin);
function placeTransform(p){const from=world(p.from),to=world(p.to);return {position:from.clone().add(to).multiplyScalar(.5),rotation:new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1,0,0),to.sub(from).normalize())}}
function target(){return hooks.target?hooks.target(s):(s.mode==='free'?s.freeTarget:s.mode==='learn'?6:house.families[s.family]?.length??null)}
function context(){return hooks.context?.(s)??(s.mode==='challenge'?'house:'+house.families[s.family]?.id:s.mode+':'+s.lesson)}
function remove(objects){for(const o of objects){scene.remove(o);o.traverse?.(v=>{if(v.isMesh||v.isLine)v.geometry?.dispose()})}objects.length=0}
function clearTransient(){remove(transient);piece=null;offcut=null;inspection=null;for(const id of ['result','needed','actual','checkmark','inspection-actions','complete'])$(id).hidden=true}
function addTransient(q){transient.push(q);return q}
function createPart(part){const q=plank(worldLength(part.length,part),part.tone==='dark'?woodDark:part.tone==='light'?woodLight:wood);q.userData={...part,label:`${measure(part.length,part)} Wooden Piece${part.original?' · Original':' · Equal Copy'}`};scene.add(q);return q}
function partDestination(part){if(part.project){const origin=new THREE.Vector3(...construction.projects.find(p=>p.id===part.project).origin),from=new THREE.Vector3(...part.from.map(n=>n/8)).add(origin),to=new THREE.Vector3(...part.to.map(n=>n/8)).add(origin),rotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1,0,0),to.clone().sub(from).normalize());rotation.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),part.roll??0));return {position:from.clone().add(to).multiplyScalar(.5),rotation}}if(part.family){const f=house.families.find(f=>f.id===part.family);return placeTransform(f.placements[part.placement])}const i=s.parts.filter(p=>!p.family).findIndex(p=>p.id===part.id),p=comparisonPosition(i,worldLength(part.length,part),layout);return {position:new THREE.Vector3(p.x,p.y,p.z),rotation:new THREE.Quaternion()}}
function rebuildParts(){remove(placed);remove(ghosts);comparisonRack.visible=true;for(const part of s.parts.filter(p=>s.mode!=='challenge'||!p.project||p.project===displayProject(s,construction))){const q=createPart(part),t=partDestination(part);q.position.copy(t.position);q.quaternion.copy(t.rotation);placed.push(q)}
  if(s.mode==='challenge'&&displayProject(s,construction)==='plane'){const o=construction.projects.find(p=>p.id==='plane').origin;if(s.parts.some(p=>p.step==='MT-C11'||p.step==='build:plane:MT-C11')){const hub=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,.45,12),woodDark);hub.rotation.x=Math.PI/2;hub.position.set(o[0],o[1]+10.76/8,o[2]+2.04);scene.add(hub);ghosts.push(hub)}}
  if(s.mode==='challenge'&&displayProject(s,construction)==='house'&&s.parts.some(p=>p.step==='MT-C23'||p.step==='build:house:MT-C23')){const o=construction.projects.find(p=>p.id==='house').origin;for(const side of [-1,1]){const q=box(.03,.76,.76,mat(0x88c8cf,{roughness:.25}),o[0]+side*2.43,o[1]+1.25,o[2]);ghosts.push(q)}}
  if(s.mode==='challenge'&&s.activity==='house')for(const f of house.families){if(s.completed.includes(f.id))continue;for(const p of f.placements){const q=plank(f.length/8,ghost),t=placeTransform(p);q.position.copy(t.position);q.quaternion.copy(t.rotation);q.traverse(c=>c.castShadow=false);scene.add(q);ghosts.push(q)}}
}
function homeView(){
 if(cameraChoice==='cut'||cameraChoice==='tray'){
  const left=Math.min(SAW_X-1.2,SAW_X-length(s.selected)),right=Math.max(SAW_X+1.2,SAW_X-length(s.selected)+layout.stockLength);
  const focus=cameraChoice==='cut'?new THREE.Vector3((left+right)/2,BOARD_Y,BOARD_Z):w.stagingPosition.clone();
  const span=cameraChoice==='cut'?right-left:layout.tableWidth,distance=Math.max(10,span*1.45/(2*Math.tan(35*Math.PI/360)*camera.aspect));
  return composeView({position:focus.clone().add(new THREE.Vector3(cameraChoice==='cut'?span/2+4:distance*.12,distance*.5,distance)),look:focus});
 }
 const focus=layout.modelOrigin,view=cameraChoice==='build'?{position:[focus[0]+5,focus[1]+8,focus[2]+12],look:[focus[0],focus[1]+2,focus[2]]}:null;
 const framed=view?{position:new THREE.Vector3(...view.position),look:new THREE.Vector3(...view.look)}:{position:homePos.clone(),look:homeLook.clone()};
 return composeView(framed,cameraChoice==='workshop');
}
function composeView(view,clearControls=false){
 // Frame the usable area above the ruler, only when a preset is requested.
 const offset=view.position.clone().sub(view.look),distance=offset.length(),right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),offset).normalize(),up=new THREE.Vector3().crossVectors(offset,right).normalize();
 const dock=$('dock').hidden?0:$('dock').getBoundingClientRect().height,controls=clearControls?document.querySelector('.camera-controls').getBoundingClientRect().height+12:0,shift=distance*Math.tan(35*Math.PI/360)*(dock+controls)/Math.max(1,$('stage').clientHeight);
 view.position.addScaledVector(up,-shift);view.look.addScaledVector(up,-shift);return view;
}
function home(){const view=homeView(),direction=view.position.clone().sub(view.look),distance=direction.length();direction.normalize();look.copy(view.look);camera.position.copy(look).addScaledVector(direction,w.clearOrbitRadius(look,direction,distance));resetOrbitPreference();preferredOrbitDistance=preferredRadius(distance,1,w.orbitLimits);render()}
const focusNames={workshop:'Workshop',cut:'Cutting Bench',tray:'Ready To Assemble',build:'Assembly Model'};
function focusView(choice){
 if(animation||!['selecting','complete'].includes(s.phase)){ $('view-focus').value=cameraChoice;return false }
 cameraChoice=choice;$('view-focus').value=choice;cancelOrbitRecovery();const ticket=focusTicket,to=homeView(),from=camera.position.clone(),fromLook=look.clone(),start=performance.now();
 const desired=preferredRadius(to.position.distanceTo(to.look),1,w.orbitLimits);
 function apply(t){const e=t*t*(3-2*t);look.lerpVectors(fromLook,to.look,e);camera.position.lerpVectors(from,to.position,e);const direction=camera.position.clone().sub(look),distance=direction.length();direction.normalize();camera.position.copy(look).addScaledVector(direction,w.clearOrbitRadius(look,direction,distance));render();labels()}
 $('object-cue').textContent='Focus: '+focusNames[choice];
 if($('reduced').checked){apply(1);preferredOrbitDistance=desired;return true}
 focusMoving=true;function frame(now){if(ticket!==focusTicket)return;const t=Math.min(1,(now-start)/450);apply(t);preferredOrbitDistance=preferredRadius(camera.position.distanceTo(look),1,w.orbitLimits);if(t<1)requestAnimationFrame(frame);else{focusMoving=false;preferredOrbitDistance=desired}}requestAnimationFrame(frame);return true;
}
function resetStock(){stock.visible=s.phase==='selecting';stock.position.set(SAW_X-length(s.selected)+layout.stockLength/2,BOARD_Y,BOARD_Z);marker.position.set(SAW_X,BOARD_Y,BOARD_Z);marker.visible=stock.visible}
function ruler(){
 const el=$('ruler'),i=instrument(s),max=i.max,metric=i.unit==='mm',fine=metric?1:16;
 const minimum=max>48?(max*14+48):650,zoom=$('ruler-scroll').classList.contains('magnified')?1.8:1;
 el.style.width=Math.max($('ruler-scroll').clientWidth,minimum)*zoom+'px';
 const width=el.clientWidth||850,pad=24,span=width-48;el.setAttribute('viewBox',`0 0 ${width} 82`);
 const step=metric?(s.subdivision===1?10:1):16/s.subdivision;
 let svg=`<rect x="1" y="14" width="${width-2}" height="62" rx="7" fill="#f0d486"/>`;
 for(let n=0;n<=max;n+=step){const x=pad+n/max*span,major=metric?n%10===0:n%16===0,h=major?30:metric?(n%5===0?20:10):n%8===0?24:n%4===0?19:n%2===0?13:8;svg+=`<line x1="${x}" x2="${x}" y1="17" y2="${17+h}" stroke="#42543e" stroke-width="${major?2:1}"/>`;if(major)svg+=`<text x="${x}" y="66" text-anchor="middle" fill="#34483a" font-family="Comic Sans MS,cursive" font-size="14">${metric?n/10:n/16}</text>`}
 if(s.mode==='learn'&&s.lesson===0&&s.lessonStage==='guided'&&s.subdivision===16)for(let n=0;n<6;n+=2){const x=pad+n/max*span,end=pad+(n+2)/max*span;svg+=`<path d="M ${x} 49 v 4 H ${end} v -4" fill="none" stroke="#805c32" stroke-width="2"/><text x="${(x+end)/2}" y="72" text-anchor="middle" font-size="9">1/8</text>`}
 // Keep the neutral marker above the numeral row so whole-inch labels remain readable.
 const x=pad+s.selected/max*span;svg+=`<line x1="${x}" x2="${x}" y1="5" y2="48" stroke="#305e7a" stroke-width="2.5"/><circle cx="${x}" cy="7" r="5" fill="#305e7a"/>`;el.innerHTML=svg;
 el.setAttribute('aria-valuenow',String(s.selected));el.setAttribute('aria-valuemax',String(max));el.setAttribute('aria-label',metric?'Length Prediction in Millimetres; Numbered Centimetres':'Length Prediction in Sixteenths of an Inch');el.setAttribute('aria-valuetext',s.mode==='challenge'||s.mode==='learn'&&s.lessonStage==='practice'?'Prediction selected; commit to inspect':measure(s.selected));
 $('ruler-unit').textContent=metric?'Centimetres / Millimetres':'Inches';
 $('readout').textContent=s.mode==='challenge'?'Mark Your Prediction':`Your Mark: ${measure(s.selected)}${metric?'':` = ${s.selected/gridStep(s)}/${s.subdivision} in`}`;
 $('left').setAttribute('aria-label','Move Left '+intervalName(s));$('right').setAttribute('aria-label','Move Right '+intervalName(s));
 $('input-help').textContent=`Each interval: ${intervalName(s).toLowerCase()}. Drag or use arrow keys; Home selects zero.`;
 el.setAttribute('aria-valuemin','0');el.setAttribute('aria-label','Length Prediction; Visible Intervals of '+intervalName(s));

}
function selectorGuidance(t){
 const i=instrument(s),scale=$('subdivision'),targetChoice=$('free-target'),names=i.unit==='in'?{2:'Halves',4:'Quarters',8:'Eighths',16:'Sixteenths'}:{1:'Centimetres',10:'Millimetres'};
 for(const option of scale.options){const unavailable=t!==null&&!onGrid(t,s,Number(option.value));option.disabled=unavailable;option.hidden=unavailable;option.setAttribute('aria-disabled',String(unavailable));}
 const required=t===null?null:[...(i.unit==='in'?[2,4,8,16]:[1,10])].find(n=>onGrid(t,s,n));
 const text=s.mode==='challenge'&&s.phase==='complete'?'Choose a build to start or continue measuring.':s.phase!=='selecting'?'Ruler choices are locked while this piece is being inspected or placed.':s.mode==='challenge'?`This build step uses ${names[s.subdivision].toLowerCase()}. The visible graduations are fixed for this cut.`:required?`This target requires ${names[required].toLowerCase()}${required===(i.unit==='in'?16:10)?'':' or finer'}. Choices that cannot show its exact length are hidden.`:'Choose the visible graduations. Pointer and arrow keys use the same intervals.';
 if($('scale-help').textContent!==text)$('scale-help').textContent=text;scale.setAttribute('aria-disabled',String(scale.disabled));scale.title=text;
 for(const option of targetChoice.options){const unavailable=Boolean(option.value)&&!onGrid(Number(option.value),s);option.disabled=unavailable;option.hidden=unavailable;option.setAttribute('aria-disabled',String(unavailable));}
 targetChoice.disabled=s.phase!=='selecting';targetChoice.setAttribute('aria-disabled',String(targetChoice.disabled));$('target-help').textContent=s.phase!=='selecting'?'Comparison choices are locked until you finish this piece.':'Only targets on the current visible grid are listed. Choose finer graduations to see more targets.';
}
function update(){document.querySelector('main').dataset.mode=s.mode;if(s.phase==='selecting'){const oldSelected=s.selected;ensureVisibleTarget(s,target());if(oldSelected!==s.selected)resetStock()}$('view-focus').disabled=!['selecting','complete','reasoning'].includes(s.phase);const f=house.families[s.family],t=target();$('order').hidden=s.phase==='inspecting';$('dock').hidden=s.mode!=='challenge'&&s.phase!=='selecting';$('complete').hidden=s.phase!=='complete';$('complete').textContent='House Complete \u00b7 Three Lengths, Seventeen Pieces';$('phase').hidden=s.phase==='inspecting';$('phase').textContent={selecting:'Choose Your Cut',cutting:'Making Your Cut',approaching:'Bringing Your Piece Closer',inspecting:'Inspect Your Cut',departing:'Moving Your Piece',duplicating:'Making Equal Copies',assembling:'Into the Model',complete:'House Complete'}[s.phase]||'Workshop';
  for(const b of document.querySelectorAll('[data-mode]'))b.setAttribute('aria-pressed',String(b.dataset.mode===s.mode));
  $('kicker').textContent=s.mode==='free'?'Your Workshop':s.mode==='learn'?'Guided Learning':'Model House';$('order-title').textContent=s.mode==='free'?'Choose a Length':s.mode==='learn'?'Start at Zero':f?.title??'House Complete';$('target').innerHTML=t===null?'Any Length':`${hooks.targetLabel?.(s)?hooks.targetLabel(s)+' in':measure(t)}`;$('order-note').textContent=s.mode==='free'?'Keep, compare, and cut again.':s.mode==='learn'?'Start at the zero graduation.':f?`One accepted measurement · ${f.placements.length} equal pieces`:'Three measured lengths · Seventeen pieces';
  $('learning-controls').hidden=s.mode!=='learn';$('challenge-controls').hidden=s.mode!=='challenge';$('free-controls').hidden=s.mode!=='free';$('instrument').textContent=instrument(s).title;$('free-target').value=s.freeTarget??'';$('subdivision').value=s.subdivision;$('subdivision').disabled=s.mode==='challenge'||s.phase!=='selecting';selectorGuidance(t);$('cut').disabled=s.phase!=='selecting'||s.selected===0;$('left').disabled=$('right').disabled=s.phase!=='selecting';$('ruler').setAttribute('aria-disabled',String(s.phase!=='selecting')); $('progress').textContent=s.mode==='challenge'&&s.activity==='house'?`${s.parts.length} of 17 Pieces`:`${s.parts.length} Kept Pieces`;$('evidence').textContent=`${s.attempts.length} committed measurements`;$('duplicate').disabled=s.phase!=='selecting'||!s.parts.length;
  $('piece-list').replaceChildren();if(s.mode==='free')s.parts.forEach(p=>{const b=document.createElement('button');b.textContent=`${p.id}: ${measure(p.length,p)}`;b.onclick=()=>{const mesh=placed.find(q=>q.userData.id===p.id);highlight(mesh);const d=Math.max(9,worldLength(p.length,p)*1.3/(2*Math.tan(35*Math.PI/360)*camera.aspect));look.copy(mesh.position);camera.position.copy(look).add(new THREE.Vector3(d*.2,d*.4,d));resetOrbitPreference();orbit(0,0,1);render()};$('piece-list').append(b)});
  hooks.update?.(s);ruler();layoutOverlays();render();
}
function layoutOverlays(){
 // Wrapped guidance and browser zoom change the dock height. Keep the existing
 // scrollable lesson card and camera controls clear of its actual top edge.
 if(!$('dock').hidden)$('stage').style.setProperty('--dock-height',$('dock').getBoundingClientRect().height+'px');
}
function keepMarkerVisible(){const scroll=$('ruler-scroll'),x=24+s.selected/instrument(s).max*($('ruler').clientWidth-48),margin=64;if(x<scroll.scrollLeft+margin)scroll.scrollLeft=Math.max(0,x-margin);else if(x>scroll.scrollLeft+scroll.clientWidth-margin)scroll.scrollLeft=x-scroll.clientWidth+margin}
function move(n){if(s.phase!=='selecting')return;s.selected=snapToGrid(n,s);ruler();keepMarkerVisible();const from=stock.position.x,to=SAW_X-length(s.selected)+layout.stockLength/2,start=performance.now(),ticket=++shiftToken;if($('reduced').checked){stock.position.x=to;render();return}function frame(now){if(ticket!==shiftToken||s.phase!=='selecting')return;const t=Math.min(1,(now-start)/210);stock.position.x=from+(to-from)*(1-(1-t)**3);render();if(t<1)requestAnimationFrame(frame)}requestAnimationFrame(frame)}
function run(ms,fn,done){cancelOrbitRecovery();const ticket=++token,start=performance.now();const finish=()=>{if(ticket!==token)return;token++;animation=null;$('skip').hidden=true;fn(1,1);render();done?.()};animation={finish};$('skip').hidden=false;if($('reduced').checked){finish();return}function frame(now){if(ticket!==token)return;const t=Math.min(1,(now-start)/ms);fn(t*t*(3-2*t),t);render();if(t<1)requestAnimationFrame(frame);else finish()}requestAnimationFrame(frame)}
function settle(){let count=0;while(animation&&count++<8)animation.finish()}
function sound(){if($('mute').checked)return;try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.type='triangle';o.frequency.setValueAtTime(190,c.currentTime);o.frequency.exponentialRampToValueAtTime(85,c.currentTime+.22);g.gain.setValueAtTime(.025,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.24);o.connect(g).connect(c.destination);o.start();o.stop(c.currentTime+.25);o.onended=()=>c.close()}catch{}}
function cut(){if(hooks.beforeCut?.(s)===false)return;if(!commit(s,target(),context(),{copyCount:hooks.copyCount?.(s)??1,targetRepresentation:hooks.targetLabel?.(s)?hooks.targetLabel(s)+' in':target()===null?null:measure(target())}))return;clearTransient();shiftToken++;resetStock();stock.visible=true;marker.visible=false;update();sound();emit('Cutting your selected length.');const particles=[];for(let i=0;i<32;i++){const q=addTransient(box(.06,.05,.04,i%2?woodLight:woodDark,SAW_X,BOARD_Y,BOARD_Z));q.visible=false;particles.push(q)}run(1000,(e,t)=>{bladeGroup.position.y=layout.bladeY-Math.sin(t*Math.PI)*layout.bladeTravel;guard.position.y=bladeGroup.position.y;bladeGroup.rotation.x=t*16;particles.forEach((p,i)=>{const u=Math.max(0,(t-.24)*1.55);p.visible=t>.24&&t<.94;p.position.set(SAW_X+Math.sin(i*2.39)*1.6*u,BOARD_Y+.12+(.8+i%5*.28)*u-2.3*u*u,BOARD_Z+Math.cos(i*1.73)*1.5*u);p.rotation.set(u*(i+1),u*7,u*5)})},()=>{particles.forEach(p=>p.visible=false);bladeGroup.position.y=guard.position.y=layout.bladeY;stock.visible=false;piece=addTransient(plank(length(s.pending.actual)));piece.position.set(SAW_X-length(s.pending.actual)/2,BOARD_Y,BOARD_Z);scene.add(piece);if(s.pending.actual<instrument(s).max){offcut=addTransient(plank(length(instrument(s).max-s.pending.actual)));offcut.position.set(SAW_X+length(instrument(s).max-s.pending.actual)/2+.12,BOARD_Y,BOARD_Z);scene.add(offcut)}approach()})}
function inspectionView(){
 const p=s.pending,span=length(Math.max(p.actual,p.target??p.actual)),center=(span-length(p.target??p.actual))/2,d=Math.max(5.5,span*1.6/(2*Math.tan(35*Math.PI/360)*camera.aspect));
 const focus=new THREE.Vector3(...layout.inspection).add(new THREE.Vector3(center,0,0)),direction=new THREE.Vector3(0,.32,1).normalize(),radius=d*Math.hypot(.32,1);
 return {look:focus,position:focus.clone().addScaledVector(direction,w.clearOrbitRadius(focus,direction,radius))};
}
function assemblyView(parts=[]){
 const destination=parts[0]?.project?new THREE.Vector3(...layout.modelOrigin):new THREE.Vector3(layout.tableLeft+layout.tableWidth/2,layout.tableTop,layout.tableZ);
 const focus=w.stagingPosition.clone().add(destination).multiplyScalar(.5).add(new THREE.Vector3(0,2,0));
 const span=Math.max(16,...parts.map(p=>worldLength(p.length,p)))+Math.abs(destination.x-w.stagingPosition.x)+6,d=Math.max(22,span*1.4/(2*Math.tan(35*Math.PI/360)*camera.aspect));
 const direction=new THREE.Vector3(.12,.9,1).normalize();return composeView({look:focus,position:focus.clone().addScaledVector(direction,w.clearOrbitRadius(focus,direction,d*Math.hypot(.12,.9,1)))},true);
}
function approach(){
 s.phase='approaching';update();const p=s.pending,view=inspectionView(),from=piece.position.clone(),to=new THREE.Vector3(...layout.inspection).add(new THREE.Vector3(length(p.actual-(p.target??p.actual))/2,0,0)),cam=camera.position.clone(),camLook=look.clone();
 // Bring the piece forward below the raised blade, then lift above the saw.
 const front=new THREE.Vector3(from.x,from.y,44),high=front.clone().setY(layout.travelHeight),over=to.clone().setY(layout.travelHeight);
 run(1150,e=>{if(e<.2)piece.position.lerpVectors(from,front,e/.2);else if(e<.4)piece.position.lerpVectors(front,high,(e-.2)/.2);else if(e<.8)piece.position.lerpVectors(high,over,(e-.4)/.4);else piece.position.lerpVectors(over,to,(e-.8)/.2);transfer(camera.position,cam,view.position,e);look.lerpVectors(camLook,view.look,e)},inspect);
}
function dimension(parent,start,end,y,color){line([[start,y,0],[end,y,0]],color,parent);line([[start,y-.1,0],[start,y+.1,0]],color,parent);line([[end,y-.1,0],[end,y+.1,0]],color,parent)}
function inspect(){resetOrbitPreference();s.phase='inspecting';for(const mode of Object.values(sessions))exposeActivity(mode,s.pending.context);if(piece)piece.visible=false;const p=s.pending,a=length(p.actual),n=length(p.target??p.actual),left=-n/2;inspection=addTransient(new THREE.Group());inspection.position.fromArray(layout.inspection);scene.add(inspection);const material=wood.clone();if(p.target!==null){material.emissive.set(p.correct?0x279e52:0xcd3023);material.emissiveIntensity=p.correct?.25:.18}box(a,.22,.63,material,left+a/2,0,0,inspection);
  if(p.target!==null){const outline=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(n,.245,.67)),new THREE.LineBasicMaterial({color:0x587867,transparent:true,opacity:.72}));inspection.add(outline);dimension(inspection,left,n/2,.5,0x4b6d58);if(p.actual<p.target)box(n-a,.225,.645,mat(0xed6055,{transparent:true,opacity:.48,depthWrite:false}),left+a+(n-a)/2,0,0,inspection);if(p.actual>p.target){box(a-n,.24,.65,mat(0xe94c41,{transparent:true,opacity:.49,depthWrite:false}),n/2+(a-n)/2,0,0,inspection);box(.035,.255,.7,mat(0xb84236),n/2,.01,0,inspection)}}dimension(inspection,left,left+a,-.39,p.target===null?0x486679:p.correct?0x4a8857:0xb34e41);
  update();$('result').hidden=false;$('result').dataset.result=p.target===null?'neutral':p.correct?'correct':p.actual<p.target?'short':'long';$('result-title').textContent=p.target===null?'Your Cut Piece':p.correct?'A Perfect Fit':`${measure(Math.abs(p.actual-p.target))} Too ${p.actual<p.target?'Short':'Long'}`;$('result-detail').textContent=p.target===null?'Keep it to compare with another cut.':p.correct?'This piece matches the requested length.':p.actual<p.target?'The red ghost shows missing wood.':'The red section shows extra wood.';$('checkmark').hidden=!p.correct;$('needed').hidden=p.target===null;$('needed').textContent=`Needed: ${measure(p.target??p.actual)}`;$('actual').hidden=false;$('actual').textContent=`Your Piece: ${measure(p.actual)}`;$('inspection-actions').hidden=false;inspectionDetail(p);$('ack').textContent=p.correct||p.target===null||s.mode==='free'?'Keep Piece':'Try Again';labels();hooks.inspected?.(s);emit($('result-title').textContent);$('ack').focus({preventScroll:true})}
function inspectionDetail(p){let el=$('end-detail');if(!el){el=document.createElement('div');el.id='end-detail';$('result').append(el)}el.hidden=!layout.long||p.target===null;if(el.hidden)return;const radius=instrument(s).unit==='mm'?10:8,start=Math.max(0,p.target-radius),end=p.target+radius,width=270,x=n=>12+(n-start)/(end-start)*width;const actualEnd=Math.min(end,Math.max(start,p.actual));el.innerHTML=`<strong style="font-size:12px">Magnified End Comparison</strong><svg viewBox="0 0 294 60" role="img" aria-label="Magnified actual and needed endpoints at the same scale"><line x1="12" x2="${x(p.target)}" y1="17" y2="17" stroke="#42644f" stroke-width="5"/><line x1="12" x2="${x(actualEnd)}" y1="38" y2="38" stroke="${p.correct?'#34864a':'#bf4940'}" stroke-width="5"/><line x1="${x(p.target)}" x2="${x(p.target)}" y1="8" y2="46" stroke="#42644f" stroke-dasharray="3 2"/><text x="12" y="58" font-size="10">Window: ${measure(start)} to ${measure(end)}</text></svg>`;}
function labels(){if(!inspection||s.phase!=='inspecting')return;inspection.updateMatrixWorld();const p=s.pending;for(const [id,x,y] of [['needed',0,.65],['actual',length(p.actual-(p.target??p.actual))/2,-.53]]){const v=new THREE.Vector3(x,y,0).applyMatrix4(inspection.matrixWorld).project(camera);$(id).style.left=(v.x+1)/2*$('stage').clientWidth+'px';$(id).style.top=((-v.y+1)/2*$('stage').clientHeight+(layout.long?(id==='needed'?-24:24):0))+'px'}}
function nextSelection(){clearTransient();s.pending=null;s.phase=hooks.complete?.(s)||hooks.isComplete?.(s)||s.mode==='challenge'&&s.activity==='house'&&s.family===house.families.length?'complete':hooks.waiting?.(s)?'reasoning':'selecting';s.hint=false;hooks.selecting?.(s);if(s.phase==='selecting')ensureVisibleTarget(s,target());if(s.phase==='complete'&&s.mode==='challenge'&&s.parts.some(p=>p.project)){cameraChoice='build';$('view-focus').value=cameraChoice}home();resetStock();update();if(s.phase==='selecting')$('ruler').focus({preventScroll:true})}
function transfer(out,from,to,t){const height=Math.max(layout.travelHeight,from.y,to.y)+.5;if(t<.2)out.copy(from).lerp(new THREE.Vector3(from.x,height,from.z),t/.2);else if(t<.8)out.set(from.x+(to.x-from.x)*(t-.2)/.6,height,from.z+(to.z-from.z)*(t-.2)/.6);else out.set(to.x,height+(to.y-height)*(t-.8)/.2,to.z)}
function ack(){if(hooks.beforeAck?.(s)===false)return;const result=hooks.acknowledge?hooks.acknowledge(s):acknowledge(s,house);if(!result)return;const from=inspection.position.clone(),cam=camera.position.clone(),camLook=look.clone();s.phase='departing';for(const id of ['inspection-actions','needed','actual','result','checkmark'])$(id).hidden=true;update();const returnView=result.keep?assemblyView(result.parts):homeView();const destination=result.keep?w.stagingPosition.clone().sub(new THREE.Vector3(length(s.pending.actual-(s.pending.target??s.pending.actual))/2,0,0)):new THREE.Vector3(-100,104,36);run(850,e=>{if(result.keep)transfer(inspection.position,from,destination,e);else inspection.position.lerpVectors(from,destination,e);inspection.rotation.z=result.keep?0:-e*1.35;inspection.rotation.y=result.keep?0:e*.8;camera.position.lerpVectors(cam,returnView.position,e);look.lerpVectors(camLook,returnView.look,e)},()=>{if(!result.keep){hooks.rejected?.(s,result);nextSelection();return}clearTransient();if(result.replay){hooks.kept?.(s);rebuildParts();nextSelection();return}if(result.project){remove(placed);remove(ghosts);for(const part of s.parts.filter(p=>p.project===result.project&&!result.parts.includes(p))){const q=createPart(part),t=partDestination(part);q.position.copy(t.position);q.quaternion.copy(t.rotation);placed.push(q)}}const all=result.parts.map(createPart);all.forEach(q=>q.position.copy(w.stagingPosition));placed.push(...all);s.phase='duplicating';update();$('phase').textContent=`1 Original + ${all.length-1} Equal Copies`;run(1000,e=>all.forEach((q,i)=>{q.position.copy(w.stagingPosition).add(new THREE.Vector3(Math.sin(e*Math.PI)*.12*i,e*i*.25,0))}),()=>{s.phase='assembling';update();const starts=all.map(q=>q.position.clone()),dest=result.parts.map(partDestination);run(1500,e=>all.forEach((q,i)=>{const u=Math.max(0,Math.min(1,(e-i*.035)/(1-i*.035)));transfer(q.position,starts[i],dest[i].position,u);q.quaternion.slerpQuaternions(new THREE.Quaternion(),dest[i].rotation,u)}),()=>{rebuildParts();hooks.kept?.(s);nextSelection()})})})}
function switchMode(mode){if(!sessions[mode])return;settle();shiftToken++;clearTransient();s=sessions[mode];configureWorkspace();home();rebuildParts();resetStock();update();if(s.phase==='inspecting'){const view=inspectionView();camera.position.copy(view.position);look.copy(view.look);inspect()}}
function restart(){if(hooks.restart?.(s)===false)return;settle();sessions[s.mode]=restartSession(s);switchMode(s.mode);emit('This mode has restarted. Other modes are unchanged. Response history is retained. Previously viewed answers remain marked as support.')}
function duplicate(){if(s.mode!=='free'||s.phase!=='selecting'||!s.parts.length)return;const original=s.parts.at(-1);s.parts.push({...original,id:s.parts.length+1,original:false});rebuildParts();update();emit('One equal copy added. No measurement response recorded.')}
function highlight(q){if(highlighted)highlighted.traverse(c=>{if(c.material?.emissive&&c.userData.priorEmissive){c.material.emissive.copy(c.userData.priorEmissive);c.material.emissiveIntensity=c.userData.priorIntensity}});highlighted=q;if(q)q.traverse(c=>{if(c.isMesh){c.material=c.material.clone();c.userData.priorEmissive=c.material.emissive.clone();c.userData.priorIntensity=c.material.emissiveIntensity;c.material.emissive.set(0x15a8ba);c.material.emissiveIntensity=.35}});$('object-cue').textContent=q?`◆ Selected: ${q.userData.label||'Wooden Piece'}`:'Drag the workshop to look around.';render()}
function orbit(dx,dy=0,zoom=1){
 if(animation)return;
 cancelOrbitRecovery();
 const ticket=orbitTicket,offset=camera.position.clone().sub(look),spherical=new THREE.Spherical().setFromVector3(offset),limits=w.orbitLimits;
 preferredOrbitDistance=preferredRadius(preferredOrbitDistance??spherical.radius,zoom,limits);
 spherical.theta+=dx;spherical.phi=Math.max(limits.minPolar,Math.min(limits.maxPolar,spherical.phi+dy));
 const current=spherical.radius;spherical.radius=1;const direction=new THREE.Vector3().setFromSpherical(spherical);
 const clear=()=>w.clearOrbitRadius(look,direction,preferredOrbitDistance);
 let effective=Math.min(current,clear()),previous=performance.now();
 function apply(){camera.position.copy(look).addScaledVector(direction,effective);render();labels()}
 if($('reduced').checked)effective=clear();
 apply();orbitRecovering=effective<clear()-.005;
 function frame(now){
  if(ticket!==orbitTicket||animation)return;
  effective=recoverRadius(effective,clear(),Math.min(.1,(now-previous)/1000),$('reduced').checked);previous=now;
  apply();orbitRecovering=effective<clear()-.005;if(orbitRecovering)requestAnimationFrame(frame);
 }
 if(orbitRecovering)requestAnimationFrame(frame);
}
function pointerScreen(){const b=w.renderer.domElement.getBoundingClientRect();scene.updateMatrixWorld(true);const v=pointerHandle.getWorldPosition(new THREE.Vector3()).project(camera);return {x:b.left+(v.x+1)*b.width/2,y:b.top+(1-v.y)*b.height/2};}
function boardPointer(e){scene.updateMatrixWorld(true);const b=w.renderer.domElement.getBoundingClientRect(),ray=new THREE.Raycaster();ray.setFromCamera(new THREE.Vector2((e.clientX-b.left)/b.width*2-1,1-(e.clientY-b.top)/b.height*2),camera);return ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),-pointerHandle.getWorldPosition(new THREE.Vector3()).y),new THREE.Vector3());}
let drag=null;
const onCutHandle=e=>{const p=pointerScreen();return s.phase==='selecting'&&marker.visible&&Math.hypot(e.clientX-p.x,e.clientY-p.y)<23};
function sceneHit(e){
 const groups=w.focusObjects(),b=w.renderer.domElement.getBoundingClientRect(),ray=new THREE.Raycaster();
 const targets=[...placed,stock,...groups.cut,...groups.tray,comparisonRack,...ghosts].filter(q=>q.visible);
 scene.updateMatrixWorld(true);ray.setFromCamera(new THREE.Vector2((e.clientX-b.left)/b.width*2-1,1-(e.clientY-b.top)/b.height*2),camera);
 const hit=ray.intersectObjects(targets,true)[0];if(!hit)return null;
 const contains=q=>{for(let p=hit.object;p;p=p.parent)if(p===q)return true;return false};
 const piece=[...placed,stock].find(contains);
 if(piece)return {piece,focus:piece.userData.project?'build':null};
 return {focus:groups.cut.some(contains)?'cut':groups.tray.some(contains)?'tray':'build'};
}
function hoverFocus(e){
 const handle=onCutHandle(e),hit=handle?null:sceneHit(e),allowed=!animation&&['selecting','complete'].includes(s.phase),focus=allowed&&hit?.focus;
 w.renderer.domElement.style.cursor=handle?'grab':focus||hit?.piece?'pointer':'';
 $('object-cue').textContent=handle?'Drag Cut Pointer':focus?'Click To Focus: '+focusNames[focus]:hit?.piece?'Click To Highlight Wood':'Drag the workshop to look around.';
}
w.renderer.domElement.addEventListener('pointerdown',e=>{if(e.button!==0)return;const point=onCutHandle(e)?boardPointer(e):null;if(point||focusMoving)cancelOrbitRecovery();drag={id:e.pointerId,x:e.clientX,y:e.clientY,originX:e.clientX,originY:e.clientY,moved:false,cut:!!point,startX:point?.x,startSelected:s.selected};e.currentTarget.setPointerCapture(e.pointerId);if(point)e.preventDefault()});
w.renderer.domElement.addEventListener('pointermove',e=>{
 if(!drag){hoverFocus(e);return}if(drag.id!==e.pointerId)return;
 const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
 if(Math.hypot(e.clientX-drag.originX,e.clientY-drag.originY)>6)drag.moved=true;
 if(drag.cut){const point=boardPointer(e);if(point)move(drag.startSelected+(point.x-drag.startX)/worldLength(1,s));$('cut').disabled=s.selected===0;e.preventDefault()}
 else if(drag.moved)orbit(-dx*.005,-dy*.004);
 drag.x=e.clientX;drag.y=e.clientY;
});
w.renderer.domElement.addEventListener('pointerup',e=>{if(!drag||drag.id!==e.pointerId)return;if(drag.cut)hooks.updatedInput?.(s);else if(!drag.moved){const hit=sceneHit(e);if(hit?.piece)highlight(hit.piece);if(hit?.focus)focusView(hit.focus)}drag=null;if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId)});
w.renderer.domElement.addEventListener('pointerleave',()=>{if(!drag){w.renderer.domElement.style.cursor='';$('object-cue').textContent='Drag the workshop to look around.'}});
w.renderer.domElement.addEventListener('pointercancel',()=>{drag=null});w.renderer.domElement.addEventListener('lostpointercapture',()=>{drag=null});
w.renderer.domElement.addEventListener('wheel',e=>{e.preventDefault();orbit(0,0,e.deltaY>0?1.06:.94)},{passive:false});

$('cut').onclick=cut;$('ack').onclick=ack;$('left').onclick=()=>{move(s.selected-gridStep(s));update()};$('right').onclick=()=>{move(s.selected+gridStep(s));update()};
let rulerPointer=null;
const movePointer=e=>{const b=$('ruler').getBoundingClientRect();move(pickVisible(e.clientX,b.left,b.width,s));$('cut').disabled=s.phase!=='selecting'||s.selected===0};
$('ruler').onpointerdown=e=>{if(s.phase!=='selecting')return;e.preventDefault();e.stopPropagation();rulerPointer=e.pointerId;e.currentTarget.setPointerCapture(e.pointerId);movePointer(e);$('ruler').focus({preventScroll:true})};
$('ruler').onpointermove=e=>{if(rulerPointer===e.pointerId){e.preventDefault();movePointer(e)}};
const endRulerPointer=e=>{if(rulerPointer===e.pointerId){rulerPointer=null;if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);hooks.updatedInput?.(s)}};
$('ruler').onpointerup=endRulerPointer;$('ruler').onpointercancel=endRulerPointer;$('ruler').onlostpointercapture=()=>{rulerPointer=null};
$('ruler').onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End','Enter'].includes(e.key))e.preventDefault();if(e.key==='ArrowLeft')move(s.selected-gridStep(s));if(e.key==='ArrowRight')move(s.selected+gridStep(s));if(e.key==='Home'){move(0);$('ruler-scroll').scrollLeft=0}if(e.key==='End')move(instrument(s).max);if(e.key==='Enter')cut();else update()};

for(const b of document.querySelectorAll('[data-mode]'))b.onclick=()=>{switchMode(b.dataset.mode);hooks.modeEntered?.(s)};
$('skip').onclick=settle;$('restart').onclick=restart;$('duplicate').onclick=duplicate;$('free-target').onchange=()=>{if(s.phase==='selecting'){s.freeTarget=$('free-target').value?Number($('free-target').value):null;update()}};$('subdivision').onchange=()=>{const next=Number($('subdivision').value);if(s.phase!=='selecting'||target()!==null&&!onGrid(target(),s,next)){update();return}s.subdivision=next;move(s.selected);update()};$('magnify').onclick=()=>{const active=$('ruler-scroll').classList.toggle('magnified');$('magnify').setAttribute('aria-pressed',String(active));ruler()};$('reduced').checked=matchMedia('(prefers-reduced-motion: reduce)').matches;$('reduced').onchange=()=>$('mt-cut-study').dataset.reduced=String($('reduced').checked);$('reduced').onchange();$('orbit-left').onclick=()=>orbit(-.2);$('orbit-right').onclick=()=>orbit(.2);$('zoom-in').onclick=()=>orbit(0,0,.88);$('zoom-out').onclick=()=>orbit(0,0,1.12);$('home').onclick=()=>{if(animation)return;if(s.phase==='inspecting'){const view=inspectionView();camera.position.copy(view.position);look.copy(view.look);resetOrbitPreference();render();labels()}else {cameraChoice='workshop';$('view-focus').value='workshop';home()}};$('highlight').onclick=()=>highlight(s.phase==='inspecting'?inspection:placed.at(-1)||stock);$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{emit('Full screen is unavailable in this browser.')}};
new ResizeObserver(()=>{ruler();layoutOverlays();labels()}).observe($('stage'));
new ResizeObserver(layoutOverlays).observe($('dock'));
document.addEventListener('fullscreenchange',()=>{
 const active=Boolean(document.fullscreenElement);
 $('fullscreen').textContent=active?'Exit Full Screen':'Full Screen';
 $('fullscreen').setAttribute('aria-label',active?'Exit Full Screen':'Enter Full Screen');
});
$('magnify').addEventListener('click',keepMarkerVisible);
function panel(html){$('panel').classList.toggle('challenge-panel',s.mode==='challenge');$('panel-content').innerHTML=html;if(!$('panel').open)$('panel').showModal()}
$('close-panel').onclick=()=>$('panel').close();$('curriculum').onclick=() => panel('<h2>Curriculum</h2><p>Fractional-inch interpretation for Design And Modeling 1.3. Automatic assembly is a reward, not a mastery score.</p><p><a href="docs/curriculum-content.md" target="_blank">Five Lessons and Six Checks</a></p>');$('practices').onclick=$('curriculum').onclick;$('hint').onclick=()=>{s.hint=true;emit('This attempt will be recorded as supported practice.');panel('<h2>A Measuring Hint</h2><p>Start at zero. Find the whole-inch part first, then count equal spaces for the fraction. This hint marks the next response as assisted.</p>')};
function clearanceBounds(q){if(!q)return null;scene.updateMatrixWorld(true);const b=new THREE.Box3().setFromObject(q);return {min:b.min.toArray(),max:b.max.toArray(),visible:q.visible}}
window.mtReview={clearance:()=>({stock:clearanceBounds(stock),offcut:clearanceBounds(offcut),movingCut:clearanceBounds(inspection?.children[0]||piece),tray:receivingTray.visible?receivingTray.children.map(clearanceBounds):[],parts:placed.map(clearanceBounds),layout,bench:clearanceBounds(w.benchTop),extensions:clearanceBounds(w.extensions),rack:clearanceBounds(comparisonRack)}),snapshot:()=>structuredClone(s),allSessions:()=>structuredClone(sessions),select:move,cut,acknowledge:ack,skip:settle,mode:switchMode,restart,duplicate,geometry:()=>placed.map(q=>({meshLength:q.children[0].geometry.parameters.width,profileWidth:q.children[0].geometry.parameters.depth,position:q.position.toArray(),scale:q.scale.toArray(),...q.userData})),camera:()=>camera.position.toArray()};
// Review diagnostics use the actual rendered geometry and the same orbit path
// as pointer/keyboard controls; no extra game state or production behavior.
window.mtReview.table=()=>{scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(comparisonRack),frustum=new THREE.Frustum().setFromProjectionMatrix(new THREE.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse));let worldVisible=true;for(let q=comparisonRack;q;q=q.parent)worldVisible&&=q.visible;return {visible:comparisonRack.visible,worldVisible,inFrustum:frustum.intersectsBox(bounds),children:comparisonRack.children.length,depthTest:comparisonRack.children.filter(q=>!q.userData.annotation).every(q=>q.material.depthTest),depthWrite:comparisonRack.children.filter(q=>!q.userData.annotation).every(q=>q.material.depthWrite),bounds:{min:bounds.min.toArray(),max:bounds.max.toArray()},camera:camera.position.toArray(),near:camera.near,far:camera.far};};
window.mtReview.orbit=orbit;window.mtReview.pointerScreen=pointerScreen;
window.mtReview.orbitState=()=>({preferred:preferredOrbitDistance,effective:camera.position.distanceTo(look),recovering:orbitRecovering});
window.mtReview.environment=w.environment;
window.mtReview.focusState=()=>({choice:cameraChoice,moving:focusMoving});
window.mtReview.focusHit=(x,y)=>{const e={clientX:x,clientY:y};if(onCutHandle(e))return 'handle';const hit=sceneHit(e);return hit?.piece&&!hit.focus?'piece':hit?.focus??null};
function changeInstrument(id){if(!startInstrument(s,id))return false;shiftToken++;clearTransient();configureWorkspace();rebuildParts();cameraChoice='cut';$('view-focus').value=cameraChoice;home();resetStock();update();$('ruler-scroll').scrollLeft=0;return true}
window.mtReview.changeInstrument=changeInstrument;
$('instruments').onclick=()=>{panel('<h2>Start A Measurement Workspace</h2><p>These instrument presets are review choices. Starting one clears kept comparison pieces and starts a new Free Play task. Earlier response records remain. This does not convert an unfinished measurement.</p><label>Instrument <select id="instrument-choice">'+instruments.map(i=>`<option value="${i.id}">${i.title}</option>`).join('')+'</select></label><p>The 36-inch yardstick and the 100-centimetre metre stick have different physical lengths. Existing Learn and Challenge tasks use the 3-inch ruler.</p><button id="begin-instrument">Start Workspace</button>');$('instrument-choice').value=instrument(s).id;$('begin-instrument').onclick=()=>{if(changeInstrument($('instrument-choice').value))$('panel').close()}};
$('ruler-zero').onclick=()=>{$('ruler-scroll').scrollLeft=0;$('ruler').focus({preventScroll:true})};
$('view-focus').onchange=()=>focusView($('view-focus').value);
$('room-style').onchange=() =>w.setAtmosphere($('room-style').value,$('daylight').checked);$('daylight').onchange=$('room-style').onchange;

window.mtReview.view=()=>{
  scene.updateMatrixWorld(true);
  const bounds=q=>{const b=new THREE.Box3().setFromObject(q);return {min:b.min.toArray(),max:b.max.toArray()}};
  const mesh=q=>q?{visible:q.visible,position:q.position.toArray(),length:q.children[0]?.geometry?.parameters?.width,bounds:bounds(q)}:null;
  return {camera:camera.getWorldPosition(new THREE.Vector3()).toArray(),look:look.clone().add(scene.position).toArray(),near:camera.near,aspect:camera.aspect,limits:w.orbitLimits,room:w.roomBounds,benchRise:w.benchRise,benchTop:bounds(w.benchTop),benchLegs:w.benchLegs.map(bounds),pencilCup:{position:w.pencilCup.getWorldPosition(new THREE.Vector3()).toArray(),profile:w.cupProfile.map(p=>p.toArray()),pencils:w.pencils},receivingTray:bounds(w.receivingTray),staging:w.stagingPosition.clone().add(scene.position).toArray(),obstacles:w.cameraObstacles.filter(q=>q.visible).map(bounds),walls:w.roomSurfaces.map(bounds),handle:[],handleMount:bounds(w.sawArm),leaves:w.plant.children.filter(q=>q.name==='Pointed Leaf').map(bounds),stock:mesh(stock),piece:mesh(piece),offcut:mesh(offcut),inspection:inspection?{visible:inspection.visible,bounds:bounds(inspection)}:null};
};
function comparison(actual,needed,diagnosis=false){clearTransient();stock.visible=false;marker.visible=false;const left=-needed/16,[x,y,z]=layout.inspection;for(const [length,dy] of [[needed,.4],[actual,-.3]]){const q=addTransient(plank(length/8));q.position.set(x+left+length/16,y+dy,z);scene.add(q)}if(diagnosis&&actual<needed)addTransient(box((needed-actual)/8,.225,.645,mat(0xed6055,{transparent:true,opacity:.48}),x+left+actual/8+(needed-actual)/16,y-.3,z));camera.position.set(x,y+1.78,z+7.3);look.set(x,y,z);resetOrbitPreference();render()}
export const game={manifest,THREE,get construction(){return construction},get sessions(){return sessions},replaceChallenge:(state,plan)=>{settle();construction=plan;sessions.challenge=state;switchMode('challenge')},routeChallenge:value=>{const prior=hooks;hooks=Object.fromEntries([...new Set([...Object.keys(prior),...Object.keys(value)])].map(key=>[key,(state,...args)=>(state.mode==='challenge'?value[key]:prior[key])?.(state,...args)]))},get session(){return s},house,panel,update,move,cut,settle,switchMode,nextSelection,rebuildParts,emit,comparison,observeExposure:fn=>{exposureObserver=fn},expose:id=>{for(const mode of Object.values(sessions))exposeActivity(mode,id);exposureObserver(id)},setHooks:value=>{hooks=value},$};
$('build-details').onclick=()=>panel('<h2>Build Details</h2><pre class="build-provenance">'+JSON.stringify(manifest,null,2)+'</pre>');
configureWorkspace();$('view-focus').value=cameraChoice;home();rebuildParts();resetStock();update();emit('Workshop ready. Choose a ruler position and press Cut.');
await import('./learning.js').then(m=>m.installLearning(game)).catch(e=>{if(!String(e).includes('Failed to fetch'))console.warn('Learning module:',e.message)});

await import('./catalog.js').then(m=>{m.installCatalog(game);window.mtReview.ready=true}).catch(e=>{$('load-error').hidden=false;$('load-error').textContent='Challenge could not load: '+e.message;console.error(e)});
