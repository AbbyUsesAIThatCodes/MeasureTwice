@echo off
cd /d "%~dp00.1.0_Predict-Cut-Inspect_pr-26_build-003_20261002T151336Z_gc8484ff65820_web"
set "MT_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "MT_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
start "" http://127.0.0.1:18471/
"%MT_NODE%" serve.mjs . 18471
pause
