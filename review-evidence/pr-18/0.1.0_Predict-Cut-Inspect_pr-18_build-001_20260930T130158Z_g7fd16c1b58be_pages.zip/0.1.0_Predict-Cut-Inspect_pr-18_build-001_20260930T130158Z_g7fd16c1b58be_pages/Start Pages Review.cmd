@echo off
cd /d "%~dp0"
set "MT_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "MT_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
start "" http://127.0.0.1:18447/MeasureTwice/
"%MT_NODE%" serve.mjs . 18447
pause
